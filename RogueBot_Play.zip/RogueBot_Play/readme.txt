NOTE: You must have Git Bash installed and the game should run on Git Bash

Double click on run_game.sh

         (OR)

Open Git Bash in current directory
Type ./main.exe and hit enter


Enjoy!