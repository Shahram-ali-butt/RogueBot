./main.exe
if [ $? -eq 1 ]; then
    echo "--- Execution Failed! Check the errors printed above. ---"
fi